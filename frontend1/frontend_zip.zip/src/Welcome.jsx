// import React from "react";
// import { GoogleFrame } from './components/GoogleFrame24';
// import { EmailForm } from './components/EmailForm';
// import { PasswordForm } from './components/PasswordForm';
// import { SigninButton } from './components/SigninButton';
// import WelcomeHeader from './components/WelcomeHeader';
// import PasswordConfirm from "./components/PasswordConfirm";
// import GetStarted from "./components/GetStarted";
// import './style.css';

// export const Welcome = ()=> {
//   return (
//     <div className="MainFrame">
//     <div className="Welcome1Frame">
//         <div className='WelcomeText'>Welcome to Agro Assist</div>
//       <WelcomeHeader></WelcomeHeader>
//       <EmailForm> </EmailForm>
//       <PasswordForm> </PasswordForm>
//       <PasswordConfirm></PasswordConfirm>
//       <SigninButton></SigninButton>
//       <GoogleFrame onClick={() => {}} />
//       <GetStarted></GetStarted>
      

//     </div>
//     </div>
//   );
// };

// export default Welcome;
