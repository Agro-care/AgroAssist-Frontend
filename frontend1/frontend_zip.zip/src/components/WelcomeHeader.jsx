import React from "react";
import "../style.css";

export const WelcomeHeader  = ()=> {
    return (
        <div className="Header1">
        <div className="Header2">
        <img className="HeaderImage" src="https://via.placeholder.com/30x30" />
        </div>
        <div className="HeaderText">Agro Assist</div>
        </div>
      );
    };
    
    export default WelcomeHeader;