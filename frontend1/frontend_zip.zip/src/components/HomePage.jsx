import '../style.css';
import Navbar from './Navbar';


function HomePage() {
  return (
    <div>
       
        <h1 className='HomeTitle'> Agro Assit Welcomes you in Sprint1</h1>
    <div className="HomePage">
        
      <div> <img className='Image1' src="https://images.unsplash.com/photo-1530507629858-e4977d30e9e0?q=80&w=2916&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D" alt="Farmer Image1" /></div>
      <div> <img className="Image2" src="https://plus.unsplash.com/premium_photo-1686269460464-634b48ffa27a?q=80&w=3687&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D" alt="Farmer Image2" /></div>
      <div> <img className="Image2" src="https://images.unsplash.com/photo-1691039030445-c0a1f3cad6eb?w=800&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MjJ8fGZhcm1lcnxlbnwwfDF8MHx8fDA%3D" alt="Farmer Image3" /></div>



    </div>
    </div>
  );
};


export default HomePage;