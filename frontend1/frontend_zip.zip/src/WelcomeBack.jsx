// import React from "react";
// import { GoogleFrame } from './components/GoogleFrame24';
// import { EmailForm } from './components/EmailForm';
// import { PasswordForm } from './components/PasswordForm';
// import { SigninButton } from './components/SigninButton';
// import WelcomeHeader from './components/WelcomeHeader';
// import GetStarted from "./components/GetStarted";
// import './style.css';

// export const WelcomeBack = ()=> {
//   return (
//     <div className="MainFrame">
//     <div className="Welcome1Frame">
//         <div className='WelcomeText'>Welcome Back to Agro Assist</div>
//       <WelcomeHeader></WelcomeHeader>
      
//       <EmailForm> </EmailForm>
//       <PasswordForm> </PasswordForm>
      
//       <SigninButton></SigninButton>
//       <GoogleFrame onClick={() => {}} />
      
      

//     </div>
//     </div>
//   );
// };

// export default WelcomeBack;